
/**
 * Interface to implement attack rules
 * @author adwithyamagow
 *
 */
interface AttackRules {
	 abstract Animal attack(Animal a);
}
